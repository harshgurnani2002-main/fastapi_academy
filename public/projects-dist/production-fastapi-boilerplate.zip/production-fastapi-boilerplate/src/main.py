# Production grade implementation
from fastapi import FastAPI
app = FastAPI(title='Project')
