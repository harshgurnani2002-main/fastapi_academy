# Production grade implementation
